create definer = root@localhost view pvview as
select sum(`school`.`pv`.`pv`) AS `pv`, `school`.`pv`.`uid` AS `uid`
from `school`.`pv`
group by `school`.`pv`.`uid`;

