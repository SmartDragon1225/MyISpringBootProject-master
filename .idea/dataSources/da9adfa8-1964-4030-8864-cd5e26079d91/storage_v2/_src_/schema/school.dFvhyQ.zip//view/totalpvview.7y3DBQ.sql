create definer = root@localhost view totalpvview as
select sum(`a`.`pageView`) AS `totalPv`, `a`.`uid` AS `uid`
from `school`.`article` `a`
group by `a`.`uid`;

